import wtforms
import sqlalchemy
from bs4 import BeautifulSoup
import requests
from random import randrange
from wtforms import Form, TextField, TextAreaField
from wtforms.fields.html5 import DateField
from flask_wtf import FlaskForm
from wtforms import StringField
from flask_admin.contrib.sqla import ModelView
from flask_basicauth import BasicAuth
from sqlalchemy import create_engine
from werkzeug.exceptions import HTTPException
from sqlalchemy.orm import sessionmaker
import glob

#from randomsTables import Address, Base, Person
from models import Information, Base, Ongoing, Inquery, MainPage, Products
from models import Help as Helping

#------- adding to database

from wtforms.validators import DataRequired
from flask_admin import Admin
# A very simple Flask Hello World app for you to get started with...
import smtplib
from flask import Flask, request, redirect, render_template, flash, url_for
engine = create_engine('sqlite:///info.db')
Base.metadata.bind = engine

# Bind the engine to the metadata of the Base class so that the
# declaratives can be accessed through a DBSession instance
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
# A DBSession() instance establishes all conversations with the database
# and represents a "staging zone" for all the objects loaded into the
# database session object. Any change made against the objects in the
# session won't be persisted into the database until you call
# session.commit(). If you're not happy about the changes, you can
# revert all of them back to the last commit by calling
# session.rollback()
session = DBSession()
'''
possible static file solution

@app.route('/js/<path:path>')
def send_js(path):
    return send_from_directory('js', path)


'''
app = Flask(__name__)
app.secret_key = b'supercuntdestroyerofworlds_5#y2L"F4Q8z\n\xec]/'
app.config['BASIC_AUTH_FORCE'] = True
basic_auth = BasicAuth(app)
app.config['BASIC_AUTH_USERNAME'] = 'thedude'
app.config['BASIC_AUTH_PASSWORD'] = '1029384756'
@app.route('/secret-page')
@basic_auth.required
def secret_page():
    return redirect('/checkadmin')


class customermodelviews(ModelView):
    can_delete = True  # disable model deletion
    page_size = 3  # the number of entries to display on the list view
    edit_modal = True
    delete_modal = True
    def is_accessible(self):
        if not basic_auth.authenticate():
            return flash('You must be logged in to access this page')
        else:
            return True


class MyForm(Form):
    Uname = StringField('Name')
    Subject = StringField('Subject:', [DataRequired()])
    email = StringField('Email:', [DataRequired()])
    Tbox = TextAreaField('', [DataRequired()], render_kw={'rows':20, 'cols':50})
    Job_number = StringField('job#:')
    dt = DateField('Ideal completion date', format='%Y-%m-%d')

    @app.route('/contact', methods=('GET', 'POST'))
    def contact():
        title='Request a new project'
        form = MyForm(request.form)
        if form.validate():
            newentry = Information(name=str(form.Uname.data), email=str(form.email.data), description=str(form.Tbox.data), subject=str(form.Subject.data), dtime=str(form.dt.data))
            session.add(newentry)
            session.commit()
            #server = smtplib.SMTP('smtp.gmail.com', 485)

            #Next, log in to the server
            #server.login("dmtopography@gmail.com", "")
            #server.ehlo()
            #server.starttls()
            #Send the mail
            #msg = "Hello!" # The /n separates the message from the headers
            #server.sendmail("dmtopography@gmail.com", "richbullis@gmail.com", msg)






            return redirect('/')
        return render_template('contact.html', form=form, title=title)
    @app.route('/ongoing', methods=('GET', 'POST'))
    def ongoing():
        form = MyForm(request.form)
        title = 'Update an ongoing project'
        if form.validate():
            newentry = Ongoing(job_number=str(form.Job_number.data), email=str(form.email.data), description=str(form.Tbox.data), subject=str(form.Subject.data))
            session.add(newentry)
            session.commit()

            return redirect('/')
        return render_template('ongoing.html', form=form, title=title)
    @app.route('/inquery', methods=['GET','POST'])
    def inquery():
        title = 'Ask us a question'
        form = MyForm(request.form)
        if form.validate():
            newentry = Inquery(name=str(form.Uname.data), subject=str(form.Subject.data), email=str(form.email.data), description=str(form.Tbox.data))
            session.add(newentry)
            session.commit()



        return render_template('contact.html', form=form, title=title)
    @app.route('/helpful')
    def helpful():
        title = 'need some help?'
        form = MyForm(request.form)
        if form.validate():
            newentry = Helping(name=str(form.Uname.data), subject=str(form.Subject.data), email=str(form.email.data), description=str(form.Tbox.data))
            session.add(newentry)
            session.commit()
        return render_template('contact.html', title=title, form=form)

@app.route('/')
def main():
    m = session.query(MainPage)
    return render_template('main.html', m=m)
@app.route('/all')
def all_photos():
    newphoto = []
    photos = glob.glob('/home/BallisticEngineering/mysite/static/*.jpg')
    for item in photos:
        newphoto.append(str(item).split('/static/')[-1])
    return render_template('riser.html', photos=newphoto)
@app.route('/stage_risers')
def stage_risers():
    newphoto = []
    photos = glob.glob('/home/BallisticEngineering/mysite/static/risers/*.jpg')
    for item in photos:
        newphoto.append(str(item).split('/static/')[-1])
    return render_template('riser.html', photos=newphoto)
@app.route('/product')
def pduct():
    PPhotos = ['https://lh3.googleusercontent.com/8HeQawy7p5Ja6FUdYqLY8MSA3r5ync5jzZlyQaj19CwGjbBeFWGwObZkMLCRof0rTqiv-l9Emv4g3EeJhkkSeVZNY5vB26ox4Vh7fbFMzTc5dW7URLC8H3RQ8cPofd5IG6hrN3gjc2sKGXbp1poKI2f96bp-saC5bva60UEUQAU5L1cRp-RxxfH5NK5Zf29JI8wkRRJV5cf6XTAZ-46kioVLafUedt_qL1_FM9PuIX12SpMbvjAdYeJnf8s34Pz6YnAtkRZz0ZgBa82bo_hHqiRTSXc0EEuV-Gh8c_No-SJITdvbikMeLNMX_w-DK5-OJJMpYZyLX-5QFnsQXtR5NwqTTnV0wGJBPJBXa0PfHkIcNPRE7JcwpnGTSQ3YxvCrVB4am4AvyBTWLNWOmcDvQOvmkdaF0NC-hokyT80iogMh_bXCVOK7uZdNx1_6tKng56CeMb7eznlhfK7DTYYMCuKgZRtytCDtqszO0Yicj1lK54j_C1SnSTljcJYZUMeY12HPazDaI-Es0KR20nmPlFGni2I2QMOPp87D4CLHKgE2Zb99McFLm4BA8AYSdIsOvbsIMDDJEXqzhtCtsfY9VwxuqfUay7vv=s638-no',
    'https://lh3.googleusercontent.com/BmgRPUwsKaNcJDY_A014cxhg4JRRYl94lI-iZ87-D9fXlMhJTTxsgG6xYtePTlWpRM5Z6xu8jr31kwXTuGSmi6pA0CRGlGwVC7qlFZVINvPl3ZlDF9M4vr4vsodnUevD01Rvlh9zyc_ql27brXwyv8J2TUMVyrIwZuHfGoyoAYND0jS2cpWOwwHFWguF87in__lFE_MfJVXAmrvu8Ccbg-y0YbKNPCqKOZvN19B5FdEitaSfG7hrt-qFfVg4tGPrdAiZhiPl0wrRC-AauvwB2FR2tU8OjvaKfgVMXm1ZJ1sgdsUDBbeKRRYFGE0DWnM0cRZpuzRwXeq1CQJYlNODmI-ly6OGpSuFbOyF-ct4K42YyosgjfHku9MU05ZcC7NLzIizUK0f09tUHxd1NUwBQXGuXtxeIUwHbrJkq2ZQSYS9eDSEWbJwEcSkwM5u4d7bYv4G91oqOSPP_OhFCVeqrOdCfq56jmlfKqAioeciRWFWe8qJdMaZ0t-D5KoQqybnmis4s6NcKIoeqv23j_IfRdUf9dVTq3gJpBrfmu2Py8d8_e-zUGwTSWh7lqmi4f7U27_6jbQG3Mpg4FSyPdsQ5S11YG7NeZoa=s638-no',
    'https://lh3.googleusercontent.com/aP0VAyyZz893fqe-Gzh3PuWGn2jvf8aF9R5j-apDCkB6pg2rxsY-LQ3iJAiwDtIk-Pi-vzPbu_1Zt3fPKSbgVbcgoTw_a1knIgTG5IdSEw6AUrLmoWIte3U0sKu_Vi_82qYbhA1Vz8WE0dLYVTZxu-Vedlt7LKwu650r9Jf1vzkbux2Vg4kqscyV1xt5lhNZIZWO5TKR_7FreYQaDUwFPwl132Eefp0lN363LvIAqoefTtygpEaRy0cnal4sxfrkTLRGf0hcFKQXy5W3JBi1Cs4Ln7F6OKuIlaM0rC5igkA80WcufS1lnYA1jSEcMPw58kjUaxfKyb_r3kgj4pSyx8Rk22Gihrt72kv-aWZJ48KX1sNTpsx07Erpa9FNKhKbASozYa9uAusHGzoMMImsjTTvBjaF9B1Ku5ORe8nHTq0x0MczNVE2AcoXwE1-PJ0sk-YS9JclpsnKfWtGOKjGbei-DBW0nXorJClq2zk00OByE4f4OoMhQNtTxjsuvztOp2KgN_FbuG8NBk6gj6iMBXdRix8nLYOuBH1YgRhy3AalQxnEUwmDkP5UATo7hU9yIWME7oRqzacKAscM4ePAOvcOjtdI2unA=w206-h274-no',
    'https://lh3.googleusercontent.com/XhO8y9r2Sqqs77BLPnxdulEkK1f-945jO02PPU6uMC03rXR_i_3yyEaCrWR4NEm5yPh_Q4uCdMxW8hWid_tvcH99c3KjfnugKmvFEjkASzdSNY-8SBz6On-UA-EWIsopOTQRpjSONndKAXh3798u4CvltXkgep-JFeiZ6gPSaBL50euiC-GCmxsfH79WPv4BD8wQzkKv0DKcCxs5DFc3-CsGZE9-xz5-q8ARGoJ-C3y1Img9IR-7MDVWl8e8ttyvTnTvokuK0NaJnEda59tSlodWmaXK4hMbuMoK7FeSafBfDvXxS24-2eLjzqhjpNZDU7lE3uKi0SZYuEERQ7cJQ2GiX0gY3xJpp3NuoVYX6gfmgNQVme3LEzdGgU0T964k6Z19ihJ3FV1WR9P3FuIYTjpuJqK8TT7GMmfb-zT_MB5kGmB-BrL8Mobs86gMK5bgTDLq7Y6SDVgFFiNwde2w7YEXuiLjVT-w9uSZxpPHk_QQzj4S5yE_1v8il86Lru7VDoWYhOD02MQh6UbZ6pGJuOf7miw3g1dYHp2rP5GnSX9TSN_5a6zleibD-MROlzQNUgvZW-64bBN3LfAwrjxeD9BeoXVemmDV=w850-h638-no',
    'https://lh3.googleusercontent.com/RRxgQLp5MpVxXQSlkdWQXw6bIiZB-m-LcoZ5XbAPs7w6SMg_CluE08o9ecS1VMOVu741yckXeyxj5WT2wZAG0ApukyHO0o9cEKFHZgTqup1VuKemS7rkhbmrLTeVHSi8tdX3SfaLTNy2xoDQGU8aXtugtgNi1BdAXxrUQnmBCgzaSG145m2pUyJj68gJg-a1txC6jo0H7ZNvt7SJEEOjBYX4unDk5niORdP2orkD0j2PwZRLmRJvu8-H4HsFlEfIXMcMg-00HKNV45sdY9r0MKCHOQMviMDUYC4dTzvmuM-E-JDCiZnQ8q35igSE4NlrmH9LrlnL6mLbqI8gUNWTZ-uv6DgDoh_itHMdlMN34Dgb5pcTJOsamfLAT4P6xfclLpZN-byyX3HMANLC9maCX15aiOKPKP-IWq2z1ZKgbzkhSvGl_jKK23VrM7nO4A1WIKj6hBC8Opxok3-9TPPwpM7q0xgj0pV_VK0h_nDiLE4v7rH2rQk8I-Ktn0cfZdIkPURcrNKTl_e_nggIKG0En9tpaYoAfpmMsEBIbU5XCG9ZjY-Lzp2nAzTrGIBNLA3oPF1DYOiYg9BHe2g58S867BxysQiumsR0=w274-h206-no',
    'https://lh3.googleusercontent.com/K1kNMW6zICf5CoKQ0FUWVp7Q6TBDxSsMM-LiOtFLaOjbj6RnYHl3_fjps7iVeyK8XgkqqHcY3OCtaiu2Rd3a1z9qre1RVbkphlCrWkvgGdQEIFhc9KVVJ8_JjvglBjyj7Q5iMKkJvoCU25o_KdR6x4oTXEZ6nXqCigLhKo1Ue-dP_JmIxasjvNfFrksQlWLOmU52l3JuqQPCoXf4po9jSiAjR68vuXI-c-_f3yr6Q652w0Mt0v73mgVTJLKkMGrFd5hCgki3eLZIZktg7slZ7Jc-CTcqUG5HWORfb9PwOzmnQMMVhC3p0RWi2jZxWvyDYU0pSDWn64H1ROMtbQz_6PUtxJJxWBIX0PUkmmlLH1FarFJOehRZt-WVpB0yci1briE11vPOSU48-dMRJXKObSjv3eQ3T1s1jm-xNgSVkSw5xJ5TNdUrU6GH3urqTy6640gdF8FfWY0Xam348iUDhGhaLBUHg7FlECmioB6Vs4ZwuLN5wsMR4_LoBXwfFUtvceQGCXuHT4ttBYicBhGonj_0XZBYEOvyidi5-juFvR4JVuqJw4Hr6r4nBnMoTouX4H1q2Mhjahi62jMawAAFmKUf5pEexa_R=w206-h366-no']
    P = session.query(Products)


    return render_template('product.html', ok=PPhotos, P=P)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/help')
def Help():
    return render_template('help.html')

@app.route('/location')
def location():
    return render_template('location.html')
@app.route('/payments')
def payments():
    return render_template('payments.html')

admin = Admin(app, name='ballistic', template_mode='bootstrap3', url='/checkadmin')
admin.add_view(customermodelviews(Information, session))
admin.add_view(customermodelviews(Ongoing, session))
admin.add_view(customermodelviews(Inquery, session))
admin.add_view(customermodelviews(MainPage, session))
admin.add_view(customermodelviews(Products, session))
# Add administrative views here



