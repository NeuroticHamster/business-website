import sqlalchemy
import datetime
from sqlalchemy import Column, ForeignKey, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine




Base = declarative_base()



class Information(Base):
    __tablename__ = 'information'
    id = Column(Integer, primary_key=True)
    email = Column(String(100))
    name = Column(String(100))
    subject = Column(String(3000))
    description = Column(String(10000))
    dtime = Column(String(25))
class Ongoing(Base):
    __tablename__ = 'ongoing'
    id = Column(Integer, primary_key=True)
    email = Column(String(100))
    job_number = Column(Integer)
    subject = Column(String(3000))
    description = Column(String(10000))
class Inquery(Base):
    __tablename__ = 'inquery'
    id = Column(Integer, primary_key=True)
    email = Column(String(100))
    name = Column(String(100))
    subject = Column(String(3000))
    description = Column(String(10000))
class Help(Base):
    __tablename__ = 'Help'
    id = Column(Integer, primary_key=True)
    email = Column(String(100))
    name_job_number = Column(String(100))
    subject = Column(String(3000))
    description = Column(String(10000))
class MainPage(Base):
    __tablename__ = 'mainpage'
    id = Column(Integer, primary_key=True)
    time = Column(DateTime, default=datetime.datetime.utcnow)
    head = Column(String(5000))
    msg = Column(String(10000))
    vid = Column(String(6000), default='empty')
    img = Column(String(6000), default='empty')
class Products(Base):
    __tablename__ = 'products'
    id = Column(Integer, primary_key=True)
    imgclip = Column(String(6000), default='empty')
    headname = Column(String(800))
    dscript = Column(String(10000))
    vidclip = Column(String(6000), default='empty')

engine = create_engine('sqlite:///info.db')


Base.metadata.create_all(engine)